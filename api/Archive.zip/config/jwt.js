const key = "secretKey123456789$.";

export default key;
